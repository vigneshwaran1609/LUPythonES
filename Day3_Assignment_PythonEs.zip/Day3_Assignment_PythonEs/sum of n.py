n= int(input())
s=0
i=1
while(i<=n):
    s=s+i
    i+=1
print(s)